from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

hub = PrimeHub()

# Initialize color sensors
RightColor = ColorSensor(Port.A)
LeftColor = ColorSensor(Port.B)

# Initialize both motors. In this example, the motor on the
# right must turn counterclockwise to make the robot go forward.
left_motor = Motor(Port.E)
right_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)

# Initialize the drive base. In this example, the wheel diameter is 56mm.
# The distance between the two wheel-ground contact points is 112mm.
drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=112)

while not hub.imu.ready():
    wait(10)

def tilted(hub):
    return abs(hub.imu.tilt()[0] + hub.imu.tilt()[1]) > 12




def main(RightColor, LeftColor, Hub, DriveBase, LeftMotor, RightMotor):
    speed_multiplier = 2

    kp = 2.5
    kpe = 0.00001
    kpTilted = 1
    kpeTilted = 0
    kv = 0
    speed = 90
    speedTilted = 200


    while True:
        print("bateria: ", Hub.battery.voltage(), "%")
        if (not tilted(Hub)):
            #Code to run when the robot is in a flat plane
            right_reflection = RightColor.reflection()
            left_reflection = LeftColor.reflection()

            error = right_reflection - left_reflection
            reflection_sum = 200 - (right_reflection + left_reflection)
            reflection_sum /= 200 
            DriveBase.drive(speed,error * kp + kpe * (error*abs(error)))

            black_value = 25


            speed_multiplier = (0.95 * (speed_multiplier - 1)) + 1

            if reflection_sum < 0.5:
                speed_multiplier = 0.5


            if (left_reflection < black_value or right_reflection < black_value):
                drive_base.straight(20)

                if left_reflection < right_reflection:
                    print("right")
                    while (LeftColor.reflection() > black_value):
                        DriveBase.drive(20,900)
                    while (LeftColor.reflection() < black_value):
                        DriveBase.drive(20,-900)
                else:
                    print("left")
                    while (RightColor.reflection() > black_value):
                        DriveBase.drive(20,-900)
                    while (RightColor.reflection() < black_value):
                        DriveBase.drive(20,900)
        else:
            #code to run when the robot is tilted
            right_reflection = RightColor.reflection()
            left_reflection = LeftColor.reflection()

            error = right_reflection - left_reflection 
            DriveBase.drive(speedTilted,error * kpTilted + kpeTilted * (error*abs(error)))




        wait(2)


main(RightColor, LeftColor, hub, drive_base, left_motor, right_motor)