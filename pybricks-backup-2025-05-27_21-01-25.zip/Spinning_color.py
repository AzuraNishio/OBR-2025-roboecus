from pybricks.pupdevices import ColorSensor
from pybricks.pupdevices import Motor
from pybricks.parameters import Port
from pybricks.tools import wait
from umath import sin, cos, radians

# Initialize the sensor.
color_center = ColorSensor(Port.A)

time = 0

while True:
    time += 1
    print(time)
    # Read the color and reflection
    #color = color_center.color()
    #reflection = color_center.reflection()
    #error = reflection - 50
    #kp = 0.2
    #pivot.run(error * kp)
    t = 0.3
    A = 10*sin((time*t))
    B = 10*sin((time*t)+4.2)
    C = 10*sin((time*t)+8.4)
    color_center.lights.on([A,B,C])
    # Print the measured color and reflection.
    #print(color, reflection)

    # Move the sensor around and see how
    # well you can detect colors.
    
    # Wait so we can read the value.
    
