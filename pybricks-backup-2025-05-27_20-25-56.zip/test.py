from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch


hub = PrimeHub()

# Initialize color sensors
RightColor = ColorSensor(Port.A)
LeftColor = ColorSensor(Port.B)

# Initialize both motors. In this example, the motor on the
# right must turn counterclockwise to make the robot go forward.
left_motor = Motor(Port.E)
right_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)

# Initialize the drive base. In this example, the wheel diameter is 56mm.
# The distance between the two wheel-ground contact points is 112mm.
drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=112)
